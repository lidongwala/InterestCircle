module.exports = {
    testEnvironment: 'jsdom',
};
