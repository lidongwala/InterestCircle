// 处理通用的功能

document.addEventListener('DOMContentLoaded', () => {
    loadInterestCircles(); // 加载兴趣圈
});

